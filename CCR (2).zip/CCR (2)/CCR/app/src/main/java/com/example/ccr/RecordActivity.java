package com.example.ccr;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.speech.RecognizerIntent;
import android.text.InputType;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import java.util.List;
import java.util.Locale;


public class RecordActivity extends AppCompatActivity {

    private static final int REQUEST_CODE_VOICE_INPUT = 1000;
    private Spinner eventSpinner;
    private EditText attendeeEditText;
    private EditText amountEditText;
    private EditText memoEditText;
    private TextView voiceOutputTextView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_record);

        // UI 요소 초기화
        initializeUI();

        // 저장 버튼 클릭 이벤트 처리
        Button saveButton = findViewById(R.id.save_button);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                onSaveButtonClicked(view);
            }
        });

        // 음성 입력 버튼 클릭 이벤트 처리
        Button voiceInputButton = findViewById(R.id.voice_input_button);
        voiceInputButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 음성 입력 시작
                startVoiceInput();
            }
        });
    }

    private void initializeUI() {
        eventSpinner = findViewById(R.id.event_spinner);
        attendeeEditText = findViewById(R.id.attendee_edit_text);
        amountEditText = findViewById(R.id.amount_edit_text);
        memoEditText = findViewById(R.id.memo_edit_text);
        voiceOutputTextView = findViewById(R.id.voice_output_text);

        // Spinner 초기화
        initializeSpinner();

        // 기타 UI 초기화 작업
        attendeeEditText.setText("");
        attendeeEditText.setHint("참석자 입력");
        attendeeEditText.setInputType(InputType.TYPE_CLASS_TEXT);

        amountEditText.setText("");
        amountEditText.setHint("금액 입력");
        amountEditText.setInputType(InputType.TYPE_CLASS_NUMBER);

        memoEditText.setText("");
        memoEditText.setHint("메모 입력");
    }

    private void initializeSpinner() {
        // 문자열 배열을 가져와서 어댑터 생성
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this, R.array.event_types, android.R.layout.simple_spinner_item
        );

        // 드롭다운 뷰에 사용할 레이아웃 설정
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);

        // 어댑터를 Spinner에 설정
        eventSpinner.setAdapter(adapter);

        // 기본 경조사 유형 선택
        eventSpinner.setSelection(0);

        // Spinner 선택 이벤트 처리
        eventSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                // 경조사 유형을 선택하면 이벤트를 발생
                onEventSelected(eventSpinner.getSelectedItem().toString());
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });
    }

    private void startVoiceInput() {
        Intent intent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        intent.putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault().toString());

        startActivityForResult(intent, REQUEST_CODE_VOICE_INPUT);
    }

    private void onEventSelected(String event) {
        // 경조사 유형에 따라 이벤트를 발생
        switch (event) {
            case "결혼":
                // 결혼 경조사를 선택한 경우
                break;
            case "돌잔치":
                // 돌잔치 경조사를 선택한 경우
                break;
            case "상견례":
                // 상견례 경조사를 선택한 경우
                break;
            case "기타":
                // 기타 경조사를 선택한 경우
                break;
            default:
                // 해당 경조사가 없는 경우
                break;
        }
    }

    private int getIndex(Spinner spinner, String targetString) {
        for (int i = 0; i < spinner.getCount(); i++) {
            if (spinner.getItemAtPosition(i).toString().equalsIgnoreCase(targetString)) {
                return i;
            }
        }
        return 0; // 일치하는 항목을 찾지 못한 경우 기본값으로 0을 반환하거나 원하는 값으로 수정하세요.
    }

    private void onVoiceInputReceived(String spokenText) {
        // 음성 입력 결과를 분석하고, 의미를 파악
        // NLP 기술을 사용
        String event = getEventFromSpokenText(spokenText);

        // 일치하는 경조사 유형을 찾아 선택
        if (event != null) {
            eventSpinner.setSelection(getIndex(eventSpinner, event));
        } else {
            // `event`가 `null`인 경우 아무 작업도 하지 않습니다.
        }
    }

    private String getEventFromSpokenText(String spokenText) {
        // 입력된 텍스트에서 명사 추출
        String[] words = spokenText.split("\\s+"); // 공백을 기준으로 단어 분리

        // 경조사 유형에 관련된 예시 단어 (결혼, 돌잔치, 상견례 등)
        String[] eventKeywords = {"결혼", "돌잔치", "상견례", "기타"};

        for (String word : words) {
            for (String keyword : eventKeywords) {
                if (word.contains(keyword)) {
                    return keyword; // 명사에 경조사 유형 키워드가 포함된 경우 반환
                }
            }
        }

        return null; // 경조사 유형 키워드를 찾지 못한 경우 null 반환
    }

    private void onSaveButtonClicked(View view) {
        // 경조사비 정보를 가져온다.
        String event = eventSpinner.getSelectedItem().toString();
        String attendee = attendeeEditText.getText().toString();
        int amount = Integer.parseInt(amountEditText.getText().toString());
        String memo = memoEditText.getText().toString();

        // DatabaseManager 인스턴스를 생성하고 데이터베이스를 엽니다.
        DatabaseManager dbManager = new DatabaseManager(this);
        dbManager.open();

        // 경조사비 정보를 데이터베이스에 삽입합니다.
        long rowId = dbManager.insert(event, attendee, amount, memo);

        // 데이터베이스 연결을 닫습니다.
        dbManager.close();

        // 데이터베이스 삽입이 성공했는지 확인합니다.
        if (rowId != -1) {
            // 성공적으로 데이터 삽입
            Toast.makeText(this, "데이터 저장 성공", Toast.LENGTH_SHORT).show();
        } else {
            // 데이터 삽입 실패
            Toast.makeText(this, "데이터 저장 실패", Toast.LENGTH_SHORT).show();
        }

        // 경조사비 정보를 SearchActivity로 보냅니다.
        Intent intent = new Intent(this, SearchActivity.class);
        intent.putExtra("event", event);
        intent.putExtra("attendee", attendee);
        intent.putExtra("amount", amount);
        intent.putExtra("memo", memo);

        startActivity(intent);
    }
}
