package com.example.ccr;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class SearchActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_search);

        // 경조사비 정보를 가져온다.
        Intent intent = getIntent();
        String event = intent.getStringExtra("event");
        String attendee = intent.getStringExtra("attendee");
        int amount = intent.getIntExtra("amount", 0);
        String memo = intent.getStringExtra("memo");

        // 경조사비 정보를 TextView에 출력한다.
        TextView textView = findViewById(R.id.textView);
        textView.setText(String.format("경조사 유형: %s\n참석자: %s\n금액: %d원\n메모: %s", event, attendee, amount, memo));
    }

    public void onSearchButtonClicked(View view) {
        // 검색 버튼을 눌렀을 때 처리할 내용을 추가할 수 있습니다.
        // 이 코드에서는 현재 화면을 닫고 이전 화면(RecordActivity)으로 돌아갑니다.
        finish();
    }
    public void onSaveButtonClicked(View view) {
        // 경조사비 정보를 가져온다.
        Intent intent = getIntent();
        String event = intent.getStringExtra("event");
        String attendee = intent.getStringExtra("attendee");
        int amount = intent.getIntExtra("amount", 0);
        String memo = intent.getStringExtra("memo");

        // 여기에서 데이터를 저장하고, 예를 들어 SharedPreferences를 사용하여 저장할 수 있습니다.
        // SharedPreferences를 사용하는 예제를 아래에 제시하겠습니다.

        // 데이터를 저장한 후 저장 완료 메시지를 표시
        Toast.makeText(this, "데이터가 저장되었습니다.", Toast.LENGTH_SHORT).show();

        // 저장된 데이터를 SaveActivity로 전달
        Intent saveIntent = new Intent(this, SaveActivity.class);
        saveIntent.putExtra("event", event);
        saveIntent.putExtra("attendee", attendee);
        saveIntent.putExtra("amount", amount);
        saveIntent.putExtra("memo", memo);
        startActivity(saveIntent);
    }
}
