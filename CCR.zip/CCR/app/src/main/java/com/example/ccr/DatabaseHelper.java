package com.example.ccr;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

public class DatabaseHelper extends SQLiteOpenHelper {
    public static final String DATABASE_NAME = "ExpenseData.db";
    public static final int DATABASE_VERSION = 1;

    // 테이블 및 열 이름 정의
    public static final String TABLE_NAME = "Expense";
    public static final String COLUMN_ID = "_id";
    public static final String COLUMN_EVENT = "event";
    public static final String COLUMN_ATTENDEE = "attendee";
    public static final String COLUMN_AMOUNT = "amount";
    public static final String COLUMN_MEMO = "memo";

    // 테이블 생성 SQL 쿼리
    private static final String TABLE_CREATE =
            "CREATE TABLE " + TABLE_NAME + " (" +
                    COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " +
                    COLUMN_EVENT + " TEXT, " +
                    COLUMN_ATTENDEE + " TEXT, " +
                    COLUMN_AMOUNT + " INTEGER, " +
                    COLUMN_MEMO + " TEXT);";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        // 테이블 생성 SQL 실행
        db.execSQL(TABLE_CREATE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        // 이전 버전의 테이블 삭제 및 새로운 테이블 생성
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }
}
