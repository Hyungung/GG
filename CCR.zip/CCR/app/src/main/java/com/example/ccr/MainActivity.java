package com.example.ccr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // 경조사비 기록 버튼
        Button recordButton = findViewById(R.id.record_button);
        recordButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 경조사비 기록 화면으로 이동
                startActivity(new Intent(MainActivity.this, RecordActivity.class));

            }
        });

        // 경조사비 조회 버튼
        Button searchButton = findViewById(R.id.search_button);
        searchButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // 경조사비 조회 화면으로 이동
                startActivity(new Intent(MainActivity.this, SearchActivity.class));
            }
        });

        Button saveButton = findViewById(R.id.save_button);
        saveButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // SaveActivity로 이동
                startActivity(new Intent(MainActivity.this, SaveActivity.class));
            }
        });
    }
}