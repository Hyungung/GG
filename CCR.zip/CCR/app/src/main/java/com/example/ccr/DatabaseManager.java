package com.example.ccr;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.SQLException;
import android.database.sqlite.SQLiteDatabase;

public class DatabaseManager {
    private DatabaseHelper dbHelper;
    private Context context;
    private SQLiteDatabase database;

    public DatabaseManager(Context c) {
        context = c;
    }

    public DatabaseManager open() throws SQLException {
        dbHelper = new DatabaseHelper(context);
        database = dbHelper.getWritableDatabase();
        return this;
    }

    public void close() {
        dbHelper.close();
    }

    public long insert(String event, String attendee, int amount, String memo) {
        ContentValues contentValue = new ContentValues();
        contentValue.put(DatabaseHelper.COLUMN_EVENT, event);
        contentValue.put(DatabaseHelper.COLUMN_ATTENDEE, attendee);
        contentValue.put(DatabaseHelper.COLUMN_AMOUNT, amount);
        contentValue.put(DatabaseHelper.COLUMN_MEMO, memo);
        return database.insert(DatabaseHelper.TABLE_NAME, null, contentValue);
    }

    public Cursor fetch() {
        String[] columns = new String[]{
                DatabaseHelper.COLUMN_ID,
                DatabaseHelper.COLUMN_EVENT,
                DatabaseHelper.COLUMN_ATTENDEE,
                DatabaseHelper.COLUMN_AMOUNT,
                DatabaseHelper.COLUMN_MEMO
        };
        Cursor cursor = database.query(DatabaseHelper.TABLE_NAME, columns, null, null, null, null, null);
        if (cursor != null) {
            cursor.moveToFirst();
        }
        return cursor;
    }
}