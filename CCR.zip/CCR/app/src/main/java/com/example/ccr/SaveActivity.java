package com.example.ccr;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class SaveActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_save);

        // 저장된 데이터를 가져온다.
        Intent intent = getIntent();
        String event = intent.getStringExtra("event");
        String attendee = intent.getStringExtra("attendee");
        int amount = intent.getIntExtra("amount", 0);
        String memo = intent.getStringExtra("memo");

        // 가져온 데이터를 TextView에 표시한다.
        TextView textView = findViewById(R.id.saved_data_text);
        textView.setText(String.format("경조사 유형: %s\n참석자: %s\n금액: %d원\n메모: %s", event, attendee, amount, memo));
        Button backButton = findViewById(R.id.back_to_main_button);
        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // MainActivity로 돌아가기
                Intent intent = new Intent(SaveActivity.this, MainActivity.class);
                startActivity(intent);
                finish(); // 현재 화면을 닫습니다.
            }
        });
    }

}